let html5Qr;
let currentCameraId = null;
let flashlightOn = false;

function startScanner() {
    const qrRegionId = "reader";

    html5Qr = new Html5Qrcode(qrRegionId);

    Html5Qrcode.getCameras().then(cameras => {
        if (cameras.length) {
            currentCameraId = cameras.length > 1 ? cameras[1].id : cameras[0].id;

            html5Qr.start(
                currentCameraId,
                {
                    fps: 10,
                    qrbox: 250
                },
                qrCode => {
                    document.getElementById("scanOutput").innerText = qrCode;
                    saveHistory("scan", qrCode);
                },
                error => {}
            );
        }
    });
}

function toggleFlashlight() {
    if (!html5Qr) return;

    flashlightOn = !flashlightOn;

    html5Qr.applyVideoConstraints({
        advanced: [{ torch: flashlightOn }]
    }).catch(err => console.log("Flash error:", err));
}

function stopScanner() {
    if (html5Qr) {
        html5Qr.stop().then(() => {
            document.getElementById("scanOutput").innerText = "Kamera dihentikan";
        });
    }
}

function saveHistory(type, data) {
    let history = JSON.parse(localStorage.getItem("qr_history") || "[]");
    history.push({type, data, time: new Date().toISOString()});
    localStorage.setItem("qr_history", JSON.stringify(history));
}

window.onload = startScanner;