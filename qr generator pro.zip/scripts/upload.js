function processImage() {
    const file = document.getElementById("qrImage").files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(e) {
        const img = new Image();
        img.onload = function() {

            const canvas = document.getElementById("canvas");
            const ctx = canvas.getContext("2d");

            canvas.width = img.width;
            canvas.height = img.height;

            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

            const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);

            const code = jsQR(imgData.data, canvas.width, canvas.height);

            if (code) {
                document.getElementById("resultText").innerText = code.data;
                saveHistory("scan", code.data);
            } else {
                document.getElementById("resultText").innerText = "Gagal decode QR / gambar tidak valid.";
            }
        };
        img.src = e.target.result;
    };
    reader.readAsDataURL(file);
}

function saveHistory(type, data) {
    let history = JSON.parse(localStorage.getItem("qr_history") || "[]");
    history.push({type, data, time: new Date().toISOString()});
    localStorage.setItem("qr_history", JSON.stringify(history));
}