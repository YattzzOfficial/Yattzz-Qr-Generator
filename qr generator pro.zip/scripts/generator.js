function generateQR() {
    const type = document.getElementById("qrType").value;
    const value = document.getElementById("qrData").value;
    const color = document.getElementById("qrColor").value;
    const size = document.getElementById("qrSize").value;

    let formatted = formatData(type, value);

    document.getElementById("qrcode").innerHTML = "";

    new QRCode(document.getElementById("qrcode"), {
        text: formatted,
        width: size,
        height: size,
        colorDark: color,
        colorLight: "#ffffff",
    });

    saveHistory("generate", formatted);
}

function formatData(type, v) {
    switch(type){
        case "wifi": return `WIFI:T:WPA;S:${v};P:password;;`;
        case "wa": return `https://wa.me/${v}`;
        case "telegram": return `https://t.me/${v}`;
        case "email": return `mailto:${v}`;
        case "sms": return `sms:${v}`;
        case "phone": return `tel:${v}`;
        case "maps": return `https://www.google.com/maps?q=${v}`;
        default: return v;
    }
}

// PNG
function downloadPNG() {
    let img = document.querySelector("#qrcode img").src;
    downloadFile(img, "qr.png");
}

// JPG
function downloadJPG() {
    let img = document.querySelector("#qrcode img").src;
    downloadFile(img, "qr.jpg");
}

// SVG
function downloadSVG() {
    alert("SVG generator menyusul (butuh library tambahan)");
}

function downloadFile(url, filename) {
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.click();
}

function saveHistory(type, data) {
    let history = JSON.parse(localStorage.getItem("qr_history") || "[]");
    history.push({type, data, time: new Date().toISOString()});
    localStorage.setItem("qr_history", JSON.stringify(history));
}