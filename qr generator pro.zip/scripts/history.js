window.onload = loadHistory;

function loadHistory() {
    let history = JSON.parse(localStorage.getItem("qr_history") || "[]");
    const container = document.getElementById("historyList");

    if (history.length === 0) {
        container.innerHTML = "<p>Tidak ada riwayat ditemukan.</p>";
        return;
    }

    container.innerHTML = "";

    history.forEach((item, index) => {
        const div = document.createElement("div");
        div.className = "history-item";

        div.innerHTML = `
            <div>
                <p><strong>Jenis:</strong> ${item.type.toUpperCase()}</p>
                <p><strong>Data:</strong> ${item.data}</p>
                <p><small>${new Date(item.time).toLocaleString()}</small></p>
            </div>

            <div class="history-actions">
                <button onclick="copyData('${item.data.replace(/'/g, "\\'")}')">Copy</button>
                <button onclick="deleteItem(${index})" class="danger-btn-small">Hapus</button>
            </div>
        `;

        container.appendChild(div);
    });
}

function copyData(text) {
    navigator.clipboard.writeText(text);
    alert("Teks telah disalin!");
}

function deleteItem(index) {
    let history = JSON.parse(localStorage.getItem("qr_history") || "[]");
    history.splice(index, 1);
    localStorage.setItem("qr_history", JSON.stringify(history));
    loadHistory();
}

function clearHistory() {
    if (confirm("Hapus semua riwayat?")) {
        localStorage.removeItem("qr_history");
        loadHistory();
    }
}